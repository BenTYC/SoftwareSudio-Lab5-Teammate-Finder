package netdb.courses.softwarestudio.lab.rpg.player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import com.alibaba.fastjson.JSON;

public class PlayerMgr {
	// TODO: declare a proper field to store the data of users
	private List<Player> players = null;
	private HashMap<String, String> complementary_profession = null;

	public PlayerMgr(String data) {
		// TODO: parse data and generate list of players
		players = JSON.parseArray(data, Player.class);
		
		// use a hash map to store complementary profession
		complementary_profession = new HashMap<String, String>();
		complementary_profession.put("Mage", "Warrior");
		complementary_profession.put("Warrior", "Mage");
		complementary_profession.put("Archer", "Thief");
		complementary_profession.put("Thief", "Archer");

		// sort players by level (low -> high)
		// need not to do, it is for TA to check result
		Collections.sort(players, new Comparator<Player>() {
			public int compare(Player p1, Player p2) {
				if (p1.getLevel() < p2.getLevel())
					return -1;
				else
					return 1;
			}
		});
	}

	public Player getPlayer(String login) {
		// TODO: get player with the login
		for (Player p : players) {
			if (p.getLogin().equals(login))
				return p;
		}
		
		throw new PlayerNotFoundException();
	}

	public Player findTeammate(Player player) {
		// TODO: find the best team-mate for `player`
		return findClosestLevel(player, players);
	}

	private Player findClosestLevel(Player player, List<Player> players) {
		List<Player> result = new ArrayList<Player>();

		// find the closest level
		int diffLevel = 100000000;
		for (Player p : players) {
			int diff = Math.abs(p.getLevel() - player.getLevel());
			if (p.getId() != player.getId() && diff < diffLevel) {
				diffLevel = diff;
			}
		}

		// find the people equal to the closest level
		for (Player p : players) {
			int diff = Math.abs(p.getLevel() - player.getLevel());
			if (p.getId() != player.getId() && diff == diffLevel) {
				result.add(p);
			}
		}

		if (result.size() <= 1)
			return result.get(0);

		return findComplementaryProfession(player, result);
	}

	private Player findComplementaryProfession(Player player, List<Player> players) {
		List<Player> result = new ArrayList<Player>();

		// find the complementary profession
		String match = complementary_profession.get(player.getProfession());
		for (Player p : players) {
			if (p.getProfession().equals(match))
				result.add(p);
		}

		if (result.size() == 0)
			return findSmallestId(player, players);
		else if (result.size() == 1)
			return result.get(0);
		else
			return findSmallestId(player, result);
	}

	private Player findSmallestId(Player player, List<Player> players) {
		// sort players by id (low -> high)
		Collections.sort(players, new Comparator<Player>() {
			public int compare(Player p1, Player p2) {
				if (p1.getId() < p2.getId())
					return -1;
				else
					return 1;
			}
		});

		return players.get(0);
	}
	
	public List<Player> getPlayers() {
		return players;
	}

	@Override
	public String toString() {
		String str = "";
		for (Player player : players) {
			str = str + player.toString() + "\n";
		}
		return str + players.size();
	}

}
