package netdb.courses.softwarestudio.lab.rpg.player;

public class PlayerNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = -1209088715686627573L;

}
