package netdb.courses.softwarestudio.lab.rpg.player;

public class Player {
	// TODO: fill the Player class with proper fields and methods
	private int id;
	private String login;
	private String name;
	private String profession;
	private int level;
	
	public Player() {
		
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getLogin() {
		return login;
	}
	
	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getProfession() {
		return profession;
	}
	
	public void setProfession(String profession) {
		this.profession = profession;
	}
	
	public int getLevel() {
		return level;
	}
	
	public void setLevel(int level) {
		this.level = level;
	}

	@Override
	public String toString() {
		// TODO: return the string of the player with the format
		// ${id}/${login}/${profession}/${level}/${name}
		// For example:
		// 12/103062512/Archer/20/CoolBrandon
		return id + "/" + login + "/" + profession + "/" + level + "/" + name;
	}

}
